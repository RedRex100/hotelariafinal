from flask import Blueprint, render_template, request, jsonify, flash, session, redirect, url_for
from models.reserva_model import Reserva
from controllers.usuario_reserva_controller import adicionar_reserva_usuario, adicionar_total

reservas = Blueprint('reservas', __name__)

@reservas.route('/reservar', methods=['POST'])
def reservar():
    data = request.get_json()
    nome = data.get('nome')
    quarto = data.get('quarto')
    pagamento = data.get('formapagamento')
    diferenca = data.get('diferenca')
    data1 = data.get('data1')
    data2 = data.get('data2')

    nova_reserva = Reserva(nome, quarto, pagamento, diferenca, data1, data2)
    adicionar_reserva_usuario(nome, nova_reserva)
    adicionar_total(nome, diferenca*300)

    return jsonify({"redirect": "/registros"}), 200

@reservas.route('/reservas')
def reservas():
    if session.get('nome') is None:
        flash("Você não está logado!")
        return redirect(url_for('inicio'))
    return render_template('reservas.html')