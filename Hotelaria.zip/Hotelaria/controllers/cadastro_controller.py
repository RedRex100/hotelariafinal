from flask import Blueprint, render_template, request, jsonify
from controllers.usuario_reserva_controller import adicionar_usuario

cadastro_controller = Blueprint('cadastro', __name__)

@cadastro_controller.route('/')
def inicio():
    return render_template('inicio.html')

@cadastro_controller.route('/cadastrar')
def cadastrar():
    return render_template('cadastro.html')

@cadastro_controller.route('/cadastro', methods=['POST'])
def cadastro():
    data = request.get_json()
    nome = data.get('nome')
    endereco = data.get('endereco')
    cpf = data.get('cpf')
    telefone = data.get('telefone')
    email = data.get('email')
    senha = data.get('senha')

    # Armazenar o usuário na lista
    adicionar_usuario(nome, endereco, cpf, telefone, email, senha)

    return jsonify({"redirect": "/login"}), 200