from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models.usuario_model import usuarios

login_controller = Blueprint('login', __name__)

@login_controller.route('/login', methods = ['GET', 'POST'])
def login():
    if session.get('nome') is None:
        if request.method == 'POST':
            nome = request.form['nome']
            senha = request.form['senha']
            for usuario in usuarios:
                if usuario.nome == nome and usuario.senha == senha:
                    session['nome'] = nome
                    return redirect(url_for('cadastro.inicio'))
        return render_template('login.html')
    else:
        flash('Você já está logado!')
        return redirect(url_for('cadastro.inicio'))

@login_controller.route('/logout')
def logout():
    session.pop('nome', None)
    return redirect(url_for('login.login'))