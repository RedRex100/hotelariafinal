from controllers.cadastro_controller import *
from controllers.checkout_controller import *
from controllers.frigobar_controller import *
from controllers.login_controller import *
from controllers.pagamentos_controller import *
from controllers.reservas_controller import *
from controllers.servicos_controller import *
from controllers.usuario_reserva_controller import *