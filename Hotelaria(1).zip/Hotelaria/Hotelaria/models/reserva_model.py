class Reserva:
    def __init__(self, nome, quarto, pagamento, diferenca, data1, data2):
        self.nome = nome
        self.quarto = quarto
        self.pagamento = pagamento
        self.diferenca = diferenca
        self.data1 = data1
        self.data2 = data2